import BarraLateral from "../../componentes/barraLateral/BarraLateral";
import "./sobre.css";

function Sobre() {
    return (
      <>
        <BarraLateral />
      </>
    );
}

export default Sobre;